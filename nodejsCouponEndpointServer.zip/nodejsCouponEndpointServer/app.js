const express=require('express')
const BodyParser=require('body-parser')
const mongoose= require('mongoose')
const app=express()
app.use(BodyParser.urlencoded({extended:true}))
mongoose.connect("mongodb://localhost:27017/coupondb",{useNewUrlParser:true})
app.set('view engine','ejs')
//Schema creation
const couponSchema= new mongoose.Schema({
  code:{
    type:String,
    required:[true,"Please check the coupon code"]
  },

  type:{
    type:String,
    enum:['Flat','percentage'],
    required:[true,"Please check the coupon code"]
  },
  StartDate:  {
      type:Date,
      required:[true,"Please check the coupon code"]
    },
   EndDate:  {
          type:Date,
          required:[true,"Please check the coupon code"]
        },
   Discount:{
     type:Number,
     required:[true,"Please check the coupon code"]

   },
   minAmount:Number,
  maxAmount:Number,
})
//collection creation
const coupon= mongoose.model("coupon",couponSchema)
//developer made coupons
const coupon1= new coupon({
  code:"Helllo",
  type:"Flat",
  StartDate:'2020-01-12' ,
  EndDate: '2020-07-25',
  Discount:40,
   minAmount:1500
})
const coupon2= new coupon({
  code:"abrakadabra",
  type:"percentage",
  StartDate:'2020-01-12' ,
  EndDate:'2020-10-12' ,
  Discount: 10,
   minAmount:1000,
   maxAmount:400
})
const coupon3= new coupon({
  code:"DISCOUNT",
  type:"percentage",
  StartDate: '2020-01-12',
  EndDate:'2020-03-12' ,
  Discount: 5,
   minAmount:950,
   maxAmount:300
})
const coupon4= new coupon({
  code:"BAYERN",
  type:"Flat",
  StartDate:'2020-01-12' ,
  EndDate: '2020-04-12',
  Discount: 100,
   minAmount:1200
})
const coupon5= new coupon({
  code:"woho",
  type:"Flat",
  StartDate:'2020-01-12' ,
  EndDate: '2020-02-12',
  Discount: 30,
   minAmount:1000
})
//saving the coupons into the collection coupons
coupon.insertMany([coupon1,coupon2,coupon3,coupon4,coupon5],function(err){
  if(err){
    console.log(err);
  }
  else{
  console.log("succesfully inserted");
}
})
//using get routes to call the page where we can apply the coupon
app.get("/",function(req,res){
  res.render('home')
})
//validation of the coupon in the post route
app.post("/",function(req,res){
  //storing the variables using body parser
  const amount=parseInt(req.body.cartValue)
  const couponCode=req.body.CouponCode
// creating the current date
  const Today= new Date()
//flag for checking purpose
  var flag=0;

coupon.find(function(err,items){
  if(err){
    console.log(err);
  }
  else  {
    for(var i=0;i<items.length;i++){
      if((couponCode==items[i].code)&&(items[i].EndDate>=Today)){
        if((items[i].minAmount<=amount)&&(Today>=items[i].StartDate)){
        if(items[i].type=="Flat"){
          var dis=amount- items[i].Discount
          console.log("The amount to be paid is Rs" +dis);
         res.send("The amount to be paid is Rs" +dis)
          flag=1
          break;
        }
        else{
          var per=(amount*items[i].Discount)%100
          if(per<items[i].maxAmount){
          var dis=amount-per
          }
          else{
            var dis=amount-items[i].maxAmount
            }
          console.log("The amount to be paid is Rs" +dis);
          res.send("The amount to be paid is Rs" +dis)
           flag=1
          break;
        }
      }
      }
     }
    }

if(flag==0){
  console.log("invalid code");
  res.send("invalid code")
}
})

})
//using get route for making own choice coupon for the required
app.get("/couponmaker",function(req,res){
  res.render('createcoupon')
})
//in post route for storing the datas into the collection
app.post("/couponmaker",function(req,res){
const ccode=req.body.code
const ctype=req.body.type
const csDate=req.body.sdate
const ceDate=req.body.edate
const cdiscount=parseInt(req.body.dis)
const cmin=parseInt(req.body.min)
const cmax=parseInt(req.body.max)
const coupon6= new coupon({
  code:ccode,
  type:ctype,
  StartDate:csDate,
  EndDate:ceDate,
  Discount:cdiscount,
  minAmount:cmin,
  maxAmount:cmax
})
coupon6.save()
res.redirect("/")
})
app.listen(3000,function(){
  console.log("server is running at port 3000");
})
